<template>
  <h1>Input Mata Kuliah</h1>
  <MatkulForm></MatkulForm>
</template>

<script setup lang="ts">
import MatkulForm from '@/components/MatkulForm.vue'
</script>
