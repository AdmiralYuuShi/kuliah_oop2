<template>
  <h1>Input Mahasiswa</h1>
  <MahasiswaForm></MahasiswaForm>
</template>

<script setup lang="ts">
import MahasiswaForm from '@/components/MhsForm.vue'
</script>
