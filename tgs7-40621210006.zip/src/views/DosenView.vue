<template>
  <h1>Input Dosen</h1>
  <DosenForm></DosenForm>
</template>

<script setup lang="ts">
import DosenForm from '@/components/DosenForm.vue'
</script>
