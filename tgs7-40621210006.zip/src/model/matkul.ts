export class Matkul {
  kode: string
  nama: string

  constructor(kode: string, nama: string) {
    this.kode = kode
    this.nama = nama
  }
}
