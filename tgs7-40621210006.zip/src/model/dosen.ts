export class Dosen {
  nidn: string
  nama: string
  jenisKelamin: boolean

  constructor(nidn: string, nama: string, jenisKelamin: boolean) {
    this.nidn = nidn
    this.nama = nama
    this.jenisKelamin = jenisKelamin
  }
}
