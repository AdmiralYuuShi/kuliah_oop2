export class Mahasiswa {
  npm: string
  nama: string
  ipk: number

  constructor(npm: string, nama: string, ipk: number) {
    this.npm = npm
    this.nama = nama
    this.ipk = ipk
  }
}
